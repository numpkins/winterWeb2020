
//let box2 = document.getElementById("b2");

console.log("javascript connected woooooo")


document.getElementById("cent0").onclick = function () {
       location.href = "file:///C:/Users/pipca/Desktop/WEB%20DESIGN/code/aboutPage/index.html";
   };

document.getElementById("c1").onclick = function () {
       location.href = "file:///C:/Users/pipca/Desktop/WEB%20DESIGN/code/WhatIsCodeRedux/index.html";
   };

document.getElementById("c2").onclick = function () {
       location.href = "C:/Users/pipca/Desktop/WEB%20DESIGN/code/museumProj/index.html";
   };

   document.getElementById("c3").onclick = function () {
          location.href = "file:///C:/Users/pipca/Desktop/WEB%20DESIGN/code/Timeline/index.html";
      };

   document.getElementById("c4").onclick = function () {
          location.href = "file:///C:/Users/pipca/Desktop/WEB%20DESIGN/code/reading1/index.html";
      };

document.getElementById("c5").onclick = function () {
       location.href = "file:///C:/Users/pipca/Desktop/WEB%20DESIGN/code/reading2/index.html";
   };

   document.getElementById("c6").onclick = function () {
          location.href = "file:///C:/Users/pipca/Desktop/WEB%20DESIGN/code/reading3/index.html";
      };



      var svg = d3.select("div#navText")
  .append("svg")
  .attr("preserveAspectRatio", "xMinYMin meet")
  .attr("viewBox", "0 0 300 300")
  .classed("navContain", true);
